let nav = document.getElementById("nav");
 
function toggleNav() {
    nav.classList.toggle("show-nav");
}
